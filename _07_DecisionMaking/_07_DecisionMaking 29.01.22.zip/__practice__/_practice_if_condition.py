if 10 > 6:
    print("value is 10")
if 10 + 5:
    print("value of sum is 30")
if 10 - 5:
    print("value of expression is 5")
if 10 * 5:
    print("the product of two values is 50")
if True and True:
    print("The result is true")
else:

    print("the result is false")
if True and False:
    print("The result is true")
else:
    print("the result is false")

if False and False:
    print("the result is")
if True and False:
    print("the result is True")
else:
    print("the result is false")
if True or True:
    print("true")
if True or False:
    print("true")
if False or True:
    print("the result")
if False or False:
    print("The Result")

if 10 >= 9:
    print("The Result a is greater than b")
    print("End of program")
if 10 == 3:
    print("true")
if 10 > 5 and 10 - 5:
    print("value ")
if 5 < 12:
    print("The result")
if 15 == 15:
    print("the result")
if 10 / 2:
    print('the number is positive')
if 10 % 2:
    print("the number is ")
if 10 / 2:
    print("the result")
if 10 * 2:
    print("product of two numbers is")
if 10 is 2:
    print("identity ")

a = 43
b = 35
if a > b:
    print("a is greater")

age = int(input("enter your age :"))
if age < 18:
    print("aadhar card")
elif age < 60:
    print("voter card")
else:
    print("pension")



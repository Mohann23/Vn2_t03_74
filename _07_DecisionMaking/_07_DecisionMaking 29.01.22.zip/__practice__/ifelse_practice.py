a = 200
b = 33
if b > a:
  print("b is greater than a")
elif a == b:
  print("a and b are equal")
else:
    print(" a is greater than b")

a = 203
b = 33
print("A") if a > b else print("B")

a = 400
b = 5000
print("man") if a > b else print("women")


x = 72
y = 7
if a > b:
    print("value a")
elif a == b:
    print("value not equal")
else:
    print("value ")

x = 10
y = 12
if x > y or x < y:
    print("10 is lessthan 12")
elif x < y:
    print("y is greater")
print("---------------------------")
x = 10
y = 12
if x > y and x < y:
    print("10 is lessthan 12")
elif x < y:
    print("y is greater")
print("---End of program-----")

x = 10
y = 12
if x > y and x < y:
    print("10 is lessthan 12")
elif x > y:
    print("y is greater")
else:
    print("x is 10 ")




age = 22
if age > 18:
    print("yes")
else:
    print("no")



s = 300
p = 40
if s > p:
    print("s is greater")
a = 45
x = 46
if a > x:
    print(" x is greater")
a = 78
b = 78
if a <= b:
    print("value are same")
if a > x:
    print("a is greater")

# elif_condition
print("using elif in program")
a = 33
b = 33
if a > b:
    print("a is greater")
elif a == b:
    print("b is greater")

x = 45
y = 55
if x > y:
    print("its block")
elif x < y:
    print("its executed")

b = 10
l = 7
if b == l:
    print("laddu")
elif b > l:
    print("bharath")

# using_Else condition
a = 200
b = 45
if a < b:
    print("a is greater than b")
else:
    print("b is not greater than a")

q = 45
w = 85
if q > w:
    print("q is less than w")
elif q==w:
    print("q is equal to w")
else:
    print("w is greater than q")
# short hand if
if q < w: print("papa")
if q != w: print("super")
if q == w: print(" no")

# short hand if else

print("q") if q > w else print("w")
print("quarter") if q > w else print("water")
x = 56
y = 54
print("x") if x == y else print("y")


# pass statement
if 10 > 2:
    pass
x = 10
y = 5
if x == y:
    pass
if x != y:
    pass

# or statement
if True or False:
    print("executed")

x = 10
y = 20
if x == y or x > y:
    print(" not executed")
else:
    print("false")

x = True
y = False
if x == y:
    print("executed")
elif y or y:
    print("block")
else:
    print("yes")

print('yes') if x or y else print('no')
print("y") if x or y else print("N") if x or y else print("no")
print("yes") if 10 > 2 else print("no")






